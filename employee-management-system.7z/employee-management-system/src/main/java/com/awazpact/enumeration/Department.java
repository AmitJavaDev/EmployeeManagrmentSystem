package com.awazpact.enumeration;

public enum Department {

	Government, InHouse, Private, Overcies;

}
